document.getElementById("add-note").onclick = function () {
  let newNote = document.createElement("div");
  newNote.className = "note";
  newNote.contentEditable = "true";
  newNote.innerText = "Empty Note";
  newNote.ondblclick = function () {
    this.remove();
  };
  document.getElementById("note-container").insertBefore(newNote, this);
};

document.querySelectorAll(".note").forEach(function (note) {
  note.ondblclick = function () {
    this.remove();
  };
});
