const grid = document.querySelector(".color-grid");
const button = document.querySelector(".generate-btn");

const COLOR_COUNT = 20;

function getRandomHexColor() {
  const hex = Math.floor(Math.random() * 0xffffff).toString(16);
  return "#" + hex.padStart(6, "0");
}

function getContrastColor(hex) {
  const r = parseInt(hex.substr(1, 2), 16);
  const g = parseInt(hex.substr(3, 2), 16);
  const b = parseInt(hex.substr(5, 2), 16);
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 128 ? "#222" : "#eee";
}

function createColorBox(color) {
  const box = document.createElement("div");
  box.className = "color-box";
  box.style.backgroundColor = color;
  const text = document.createElement("span");
  text.className = "color-code";
  text.textContent = color;
  text.style.color = getContrastColor(color);
  box.appendChild(text);
  return box;
}

function generateColors() {
  grid.innerHTML = "";
  for (let i = 0; i < COLOR_COUNT; i++) {
    const color = getRandomHexColor();
    const box = createColorBox(color);
    grid.appendChild(box);
  }
}

generateColors();

button.addEventListener("click", generateColors);
