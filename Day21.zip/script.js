document.addEventListener("DOMContentLoaded", function () {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  const currentDay = now.getDate();

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  document.getElementById(
    "month-year"
  ).textContent = `${monthNames[currentMonth]} ${currentYear}`;

  function generateCalendar() {
    const calendarDays = document.getElementById("calendar-days");
    calendarDays.innerHTML = "";

    const firstDay = new Date(currentYear, currentMonth, 1).getDay();

    const lastDate = new Date(currentYear, currentMonth + 1, 0).getDate();

    const prevLastDate = new Date(currentYear, currentMonth, 0).getDate();

    for (let i = firstDay; i > 0; i--) {
      const dayElement = document.createElement("div");
      dayElement.classList.add("prev-month");
      dayElement.textContent = prevLastDate - i + 1;
      calendarDays.appendChild(dayElement);
    }

    for (let i = 1; i <= lastDate; i++) {
      const dayElement = document.createElement("div");
      if (i === currentDay) {
        dayElement.classList.add("today");
      }
      dayElement.textContent = i;
      calendarDays.appendChild(dayElement);
    }

    const daysLeft = 42 - (firstDay + lastDate);
    for (let i = 1; i <= daysLeft; i++) {
      const dayElement = document.createElement("div");
      dayElement.classList.add("next-month");
      dayElement.textContent = i;
      calendarDays.appendChild(dayElement);
    }
  }

  generateCalendar();
});
