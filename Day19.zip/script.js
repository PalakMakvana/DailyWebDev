document.getElementById("calculate").addEventListener("click", function () {
  const loanAmount = parseFloat(document.getElementById("loanAmount").value);
  const interestRate =
    parseFloat(document.getElementById("interestRate").value) / 100 / 12;
  const monthsToPay = parseInt(document.getElementById("monthsToPay").value);

  const monthlyPayment =
    (loanAmount * interestRate) /
    (1 - Math.pow(1 + interestRate, -monthsToPay));

  document.getElementById("monthlyPayment").innerText =
    monthlyPayment.toFixed(2);
});
