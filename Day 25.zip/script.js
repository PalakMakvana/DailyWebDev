(() => {
  const emojiMap = {
    1: { emoji: "😡", color: "#d14343", description: "Very Bad" },
    2: { emoji: "😞", color: "#e8a81a", description: "Bad" },
    3: { emoji: "😐", color: "#999999", description: "Okay" },
    4: { emoji: "😊", color: "#55a630", description: "Good" },
    5: { emoji: "🤩", color: "#f59e0b", description: "Excellent" },
  };

  const stars = document.querySelectorAll(".star");
  const emojiDisplay = document.getElementById("emojiDisplay");

  function updateRating(value) {
    stars.forEach((starBtn) => {
      const starValue = Number(starBtn.getAttribute("data-value"));
      if (starValue <= value) {
        starBtn.classList.add("active");
        starBtn.setAttribute("aria-checked", "true");
        starBtn.tabIndex = 0;
      } else {
        starBtn.classList.remove("active");
        starBtn.setAttribute("aria-checked", "false");
        starBtn.tabIndex = -1;
      }
    });

    const { emoji, color, description } = emojiMap[value];
    emojiDisplay.textContent = emoji;
    emojiDisplay.style.color = color;
    emojiDisplay.setAttribute("aria-label", description + " rating");
  }

  stars.forEach((starBtn) => {
    starBtn.addEventListener("click", () => {
      const rating = Number(starBtn.getAttribute("data-value"));
      updateRating(rating);
    });

    starBtn.addEventListener("keydown", (ev) => {
      let index = Array.from(stars).indexOf(ev.target);
      if (ev.key === "ArrowRight" || ev.key === "ArrowDown") {
        ev.preventDefault();
        const nextIndex = (index + 1) % stars.length;
        stars[nextIndex].focus();
      } else if (ev.key === "ArrowLeft" || ev.key === "ArrowUp") {
        ev.preventDefault();
        const prevIndex = (index - 1 + stars.length) % stars.length;
        stars[prevIndex].focus();
      } else if (ev.key === "Enter" || ev.key === " ") {
        ev.preventDefault();
        stars[index].click();
      }
    });
  });

  // Initialize rating with 2 stars as in the example
  updateRating(2);
})();
