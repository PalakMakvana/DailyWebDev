function updateClock() {
  const now = new Date();
  let hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();
  const amPm = hours >= 12 ? "PM" : "AM";

  // Convert to 12-hour format
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'

  // Pad with leading zeros
  const hourStr = String(hours).padStart(2, "0");
  const minuteStr = String(minutes).padStart(2, "0");
  const secondStr = String(seconds).padStart(2, "0");

  document.getElementById("hour").textContent = hourStr;
  document.getElementById("minutes").textContent = minuteStr;
  document.getElementById("seconds").textContent = secondStr;
  document.getElementById("am-pm").textContent = amPm;
}

setInterval(updateClock, 1000);
updateClock(); // initial call
