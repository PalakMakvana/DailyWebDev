let con = document.querySelector(".container");
let love = document.querySelector("i");

con.addEventListener("dblclick", () => {
  love.style.transform = "translate(-50%, -50%) scale(1)";
  love.style.transition = "transform 0.7s, opacity 1s";
  love.style.color = "rgb(217, 4, 111)";
  love.style.opacity = "0.7";
  setTimeout(function () {
    love.style.opacity = "0";
  }, 1000);
  setTimeout(function () {
    love.style.transform = "translate(-50%, -50%) scale(0)";
  }, 2000);
});

