(function () {
  const daysEl = document.getElementById("days");
  const hoursEl = document.getElementById("hours");
  const minutesEl = document.getElementById("minutes");
  const secondsEl = document.getElementById("seconds");
  const currentYear = new Date().getFullYear();
  const newYear = currentYear + 1;

  document.getElementById("newYear").textContent = newYear;

  // New Year's moment: Jan 1 of next year midnight
  const targetDate = new Date(`January 1, ${newYear} 00:00:00`);

  function updateCountdown() {
    const now = new Date();
    const diff = targetDate.getTime() - now.getTime();

    // Calculate time parts
    const totalSeconds = Math.floor(diff / 1000);

    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    // Show negative values if passed
    daysEl.textContent = days;
    hoursEl.textContent = hours;
    minutesEl.textContent = minutes;
    secondsEl.textContent = seconds >= 0 ? seconds : seconds - 60;

    setTimeout(updateCountdown, 1000);
  }

  updateCountdown();
})();
